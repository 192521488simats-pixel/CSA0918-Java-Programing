class ScannerStation extends Thread {
    private final String stationName;
    private final int scripts;

    ScannerStation(String stationName, int scripts) {
        super(stationName);
        this.stationName = stationName;
        this.scripts = scripts;
    }

    @Override public void run() {
        try {
            Thread.sleep(200 + (long)(Math.random() * 500));
            System.out.println(stationName + " scanned " + scripts + " scripts");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println(stationName + " was interrupted");
        }
    }
}

class RunnableStation implements Runnable {
    private final String stationName;
    private final int scripts;

    RunnableStation(String stationName, int scripts) {
        this.stationName = stationName;
        this.scripts = scripts;
    }

    @Override public void run() {
        try {
            Thread.sleep(200 + (long)(Math.random() * 500));
            System.out.println(stationName + " scanned " + scripts + " scripts");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

public class ScannerStations {
    public static void main(String[] args) throws InterruptedException {
        Thread[] stations = {
            new ScannerStation("Station-1", 25),
            new Thread(new RunnableStation("Station-2", 30)),
            new ScannerStation("Station-3", 20),
            new Thread(new RunnableStation("Station-4", 35))
        };

        for (Thread station : stations) {
            station.start();
            System.out.println(station.getName() + " alive after start: " + station.isAlive());
        }

        for (Thread station : stations) station.join();
        System.out.println("All scanner stations completed. Total scripts: 110");
    }
}
