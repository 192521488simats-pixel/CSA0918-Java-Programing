import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

public class ResultProcessor {
    static class Result {
        final String file;
        final boolean success;
        final int score;
        final String message;

        Result(String file, boolean success, int score, String message) {
            this.file = file;
            this.success = success;
            this.score = score;
            this.message = message;
        }
        @Override public String toString() {
            return file + ": " + (success ? "SUCCESS score=" + score : "FAILED " + message);
        }
    }

    static class ScoreTask implements Callable<Result> {
        private final Path file;
        ScoreTask(Path file) { this.file = file; }

        @Override public Result call() {
            try {
                String value = Files.readString(file).trim();
                int score = Integer.parseInt(value);
                if (score < 0 || score > 100)
                    throw new IllegalArgumentException("Score must be 0..100");
                return new Result(file.getFileName().toString(), true, score, "OK");
            } catch (IOException | NumberFormatException | IllegalArgumentException e) {
                return new Result(file.getFileName().toString(), false, 0, e.getMessage());
            }
        }
    }

    public static void main(String[] args) throws Exception {
        Path folder = Paths.get(args.length > 0 ? args[0] : "data");
        Files.createDirectories(folder);

        // Create small sample input files if the folder is empty.
        try (var stream = Files.list(folder)) {
            if (stream.findAny().isEmpty()) {
                Files.writeString(folder.resolve("student01.txt"), "85");
                Files.writeString(folder.resolve("student02.txt"), "72");
                Files.writeString(folder.resolve("student03.txt"), "bad-score");
                Files.writeString(folder.resolve("student04.txt"), "91");
            }
        }

        List<Path> files;
        try (var stream = Files.list(folder)) {
            files = stream.filter(p -> p.toString().endsWith(".txt")).sorted().toList();
        }

        int[] poolSizes = {1, 2, 4, 8};
        for (int poolSize : poolSizes) {
            ExecutorService pool = Executors.newFixedThreadPool(poolSize);
            ConcurrentLinkedQueue<Result> results = new ConcurrentLinkedQueue<>();
            List<Future<Result>> futures = new ArrayList<>();
            long start = System.nanoTime();

            for (Path file : files) futures.add(pool.submit(new ScoreTask(file)));
            for (Future<Result> future : futures) {
                try {
                    results.add(future.get());
                } catch (ExecutionException e) {
                    results.add(new Result("unknown", false, 0, e.getCause().toString()));
                }
            }

            pool.shutdown();
            pool.awaitTermination(1, TimeUnit.MINUTES);
            long elapsed = System.nanoTime() - start;

            long success = results.stream().filter(r -> r.success).count();
            long failure = results.size() - success;
            System.out.println("\\nPool size: " + poolSize);
            for (Result result : results) System.out.println(result);
            System.out.println("Summary: success=" + success + ", failure=" + failure);
            System.out.printf("Elapsed: %.3f ms%n", elapsed / 1_000_000.0);
        }
    }
}
