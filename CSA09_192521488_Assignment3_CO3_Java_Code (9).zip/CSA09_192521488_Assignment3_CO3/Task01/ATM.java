import java.util.InputMismatchException;
import java.util.Scanner;

public class ATM {
    private static final double BALANCE = 5000.00;

    static double withdraw(String account, double amount) {
        if (account == null || !account.matches("\\d{6,12}")) {
            throw new IllegalArgumentException("Account number must contain 6 to 12 digits.");
        }
        if (amount <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be positive.");
        }
        if (amount > BALANCE) {
            throw new IllegalArgumentException("Insufficient balance.");
        }
        if (amount % 100 != 0) {
            throw new IllegalArgumentException("Enter amount in multiples of 100.");
        }
        return BALANCE - amount;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Enter account number: ");
            String account = sc.nextLine().trim();

            System.out.print("Enter withdrawal amount: ");
            int amount = sc.nextInt();

            double remaining = withdraw(account, amount);
            System.out.printf("Withdrawal successful. Remaining balance: %.2f%n", remaining);
        } catch (InputMismatchException e) {
            System.out.println("Input error: enter the withdrawal amount as a number.");
        } catch (IllegalArgumentException e) {
            System.out.println("Transaction rejected: " + e.getMessage());
        } finally {
            System.out.println("ATM session ended.");
            sc.close();
        }
    }
}
