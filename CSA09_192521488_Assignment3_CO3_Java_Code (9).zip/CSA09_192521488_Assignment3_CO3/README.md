# Programming in Java – Assignment 3 (CO3)

**Student A:** S. Hariharan  
**Register number:** 192521488  
**Student B:** Fill in your pair member's name and register number.  
**Java version:** Java 17 or later  
**Assignment mode:** Pair work

This starter implementation contains one runnable Java program for each Q1–Q7.

## Contents
- `Task01/ATM.java` – ATM input validation, exception handling and finally
- `Task02/StorageDemo.java` – user-defined checked exceptions and exception chaining
- `Task03/SalesReport.java` – manual resource closing vs try-with-resources
- `Task04/ScannerStations.java` – Thread, Runnable, start, sleep, join and isAlive
- `Task05/SeatBooking.java` – synchronized check-then-book operation
- `Task06/TokenCounter.java` – bounded producer-consumer buffer and deadlock-safe wallet transfer
- `Task07/ResultProcessor.java` – ExecutorService, Callable, Future and concurrent result collection
- `data/` – sample score files used by Q7 (one intentionally corrupt file)

## Compile and run
From the project root, compile each task separately:

```text
javac Task01/ATM.java
java -cp Task01 ATM

javac Task02/StorageDemo.java
java -cp Task02 StorageDemo

javac Task03/SalesReport.java
java -cp Task03 SalesReport

javac Task04/ScannerStations.java
java -cp Task04 ScannerStations

javac Task05/SeatBooking.java
java -cp Task05 SeatBooking

javac Task06/TokenCounter.java
java -cp Task06 TokenCounter

javac Task07/ResultProcessor.java
java -cp Task07 ResultProcessor data
```

On Windows, use the same commands in Command Prompt or PowerShell. If `javac` is not
recognized, install a JDK and configure PATH.

## Notes for submission
- Q1 asks for at least five test inputs. Run the program with valid and invalid values and record
  your own observations.
- Q3 includes both manual close and try-with-resources examples. The demonstration catches
  processing errors so the program can continue to the next file.
- Q4 output order is intentionally not fixed because the thread scheduler decides which station
  finishes first.
- Q5 should always print `Seats sold: 10` because booking is synchronized.
- Q6 should print a token sum of 210. The wallet transfer example uses a consistent lock order.
- Q7 creates independent tasks for files, records success/failure results in a concurrent queue,
  and continues after an individual file fails.

**Important:** Run every program on your own computer, capture your own output screenshots, and
record your own timing data. Do not invent measurements or claim that sample timings are yours.
The assignment is pair work: both students must execute every question in their own repository,
complete their individual contribution sections, and be able to explain the entire solution.

## Required GitHub repository names
Each student should create their own repository:
`CSA09-<RegisterNumber>-Assignment3`

Commit progressively (at least one commit per task), add the working repository URL to the report,
and share it with the course faculty.
