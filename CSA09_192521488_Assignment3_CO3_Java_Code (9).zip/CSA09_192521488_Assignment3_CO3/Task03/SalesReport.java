import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.*;
import java.util.List;

public class SalesReport {
    // Safer version: resources are closed automatically, even when an exception occurs.
    static void createReportSafely(List<Path> inputs, Path output) {
        long total = 0;
        try (BufferedWriter writer = Files.newBufferedWriter(output)) {
            for (Path input : inputs) {
                try (BufferedReader reader = Files.newBufferedReader(input)) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        total += Long.parseLong(line.trim());
                    }
                } catch (IOException | NumberFormatException e) {
                    System.out.println("Could not process " + input + ": " + e.getMessage());
                }
            }
            writer.write("Total sales: " + total);
            writer.newLine();
            System.out.println("Report written to " + output);
        } catch (IOException e) {
            System.out.println("Could not write report: " + e.getMessage());
        }
    }

    // Demonstration of manual close in finally.
    static void readManually(Path input) {
        BufferedReader reader = null;
        try {
            reader = Files.newBufferedReader(input);
            System.out.println("Manual read " + input + ": " + reader.readLine());
        } catch (IOException e) {
            System.out.println("Manual read failed: " + e.getMessage());
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException closeError) {
                    System.out.println("Close failed: " + closeError.getMessage());
                }
            }
        }
    }

    public static void main(String[] args) throws IOException {
        Path folder = Paths.get("sales-data");
        Files.createDirectories(folder);
        Path store1 = folder.resolve("store1.txt");
        Path store2 = folder.resolve("store2.txt");
        Path bad = folder.resolve("store-corrupt.txt");
        Files.writeString(store1, "100\n200\n");
        Files.writeString(store2, "300\n150\n");
        Files.writeString(bad, "not-a-number\n");

        readManually(store1);
        createReportSafely(List.of(store1, store2, bad), folder.resolve("daily-report.txt"));
        System.out.println("Report content: " +
            Files.readString(folder.resolve("daily-report.txt")).trim());
    }
}
