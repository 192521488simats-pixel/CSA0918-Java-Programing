public class SeatBooking {
    private final boolean[] booked;
    private int bookingsMade = 0;

    SeatBooking(int seats) {
        booked = new boolean[seats];
    }

    // Synchronization makes the check-and-update one atomic critical section.
    public synchronized boolean book(int seatNumber) {
        if (seatNumber < 0 || seatNumber >= booked.length) {
            throw new IllegalArgumentException("Invalid seat number");
        }
        if (booked[seatNumber]) return false;
        booked[seatNumber] = true;
        bookingsMade++;
        return true;
    }

    public static void main(String[] args) throws InterruptedException {
        SeatBooking screen = new SeatBooking(10);
        Thread[] users = new Thread[100];

        for (int i = 0; i < users.length; i++) {
            final int seat = i % 10;
            users[i] = new Thread(() -> screen.book(seat));
            users[i].start();
        }
        for (Thread t : users) t.join();

        System.out.println("Seats sold: " + screen.bookingsMade);
    }
}
