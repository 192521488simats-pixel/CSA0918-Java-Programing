import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class PlaylistBenchmark {
    private static volatile int sink;

    private static long timeNanos(Runnable action) {
        long start = System.nanoTime();
        action.run();
        return System.nanoTime() - start;
    }

    private static List<Integer> arrayList(int n) {
        List<Integer> list = new ArrayList<>();
        for (int i = 0; i < n; i++) list.add(i);
        return list;
    }

    private static List<Integer> linkedList(int n) {
        List<Integer> list = new LinkedList<>();
        for (int i = 0; i < n; i++) list.add(i);
        return list;
    }

    private static long average(int repeats, Runnable action) {
        long total = 0;
        for (int i = 0; i < repeats; i++) total += timeNanos(action);
        return total / repeats;
    }

    public static void main(String[] args) {
        int[] sizes = {1000, 10000, 50000};
        int repeats = 3;
        System.out.println("Q2 Playlist operation benchmark (average milliseconds)");
        System.out.printf("%-9s %-14s %-14s %-14s %-14s%n",
            "Size", "Add end AL/LL", "Front insert", "Get middle AL/LL", "Iterate AL/LL");

        for (int n : sizes) {
            long alAdd = average(repeats, () -> {
                List<Integer> x = new ArrayList<>();
                for (int i = 0; i < n; i++) x.add(i);
                sink = x.size();
            });
            long llAdd = average(repeats, () -> {
                List<Integer> x = new LinkedList<>();
                for (int i = 0; i < n; i++) x.add(i);
                sink = x.size();
            });

            long alFront = average(repeats, () -> {
                List<Integer> x = arrayList(n);
                for (int i = 0; i < 100; i++) x.add(0, -i);
                sink = x.size();
            });
            long llFront = average(repeats, () -> {
                List<Integer> x = linkedList(n);
                for (int i = 0; i < 100; i++) x.add(0, -i);
                sink = x.size();
            });

            List<Integer> al = arrayList(n);
            List<Integer> ll = linkedList(n);
            long alGet = average(repeats, () -> {
                int sum = 0;
                for (int i = 0; i < 1000; i++) sum += al.get(n / 2);
                sink = sum;
            });
            long llGet = average(repeats, () -> {
                int sum = 0;
                for (int i = 0; i < 1000; i++) sum += ll.get(n / 2);
                sink = sum;
            });

            long alIter = average(repeats, () -> {
                int sum = 0; for (int v : al) sum += v; sink = sum;
            });
            long llIter = average(repeats, () -> {
                int sum = 0; for (int v : ll) sum += v; sink = sum;
            });

            System.out.printf("%-9d AL %.3f / LL %.3f  AL %.3f / LL %.3f  AL %.3f / LL %.3f  AL %.3f / LL %.3f%n",
                n, alAdd/1e6, llAdd/1e6, alFront/1e6, llFront/1e6,
                alGet/1e6, llGet/1e6, alIter/1e6, llIter/1e6);
        }

        int n = 10000;
        ArrayDeque<Integer> upNext = new ArrayDeque<>();
        long dequeTime = timeNanos(() -> {
            for (int i = 0; i < n; i++) upNext.addLast(i);
            for (int i = 0; i < 1000; i++) {
                upNext.addFirst(-i);
                upNext.pollFirst();
            }
        });
        System.out.printf("%nArrayDeque end operations at size %d: %.3f ms%n", n, dequeTime/1e6);
        System.out.println("Interpret timings cautiously: each run includes setup where shown; JVM and machine affect results.");
    }
}
