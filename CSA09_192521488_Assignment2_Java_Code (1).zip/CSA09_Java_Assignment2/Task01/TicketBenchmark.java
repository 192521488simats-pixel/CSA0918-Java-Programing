import java.util.Locale;

public class TicketBenchmark {
    private static volatile int blackHole;

    private static String buildWithPlus(int fields) {
        String result = "";
        for (int i = 0; i < fields; i++) {
            result += "FIELD-" + i + "|";
        }
        return result;
    }

    private static String buildWithBuilder(int fields) {
        StringBuilder result = new StringBuilder(fields * 10);
        for (int i = 0; i < fields; i++) {
            result.append("FIELD-").append(i).append('|');
        }
        return result.toString();
    }

    private static String buildWithBuffer(int fields) {
        StringBuffer result = new StringBuffer(fields * 10);
        for (int i = 0; i < fields; i++) {
            result.append("FIELD-").append(i).append('|');
        }
        return result.toString();
    }

    private static long measure(String method, int tickets, int fields, int repeats) {
        // Warm-up helps reduce (but does not eliminate) JVM warm-up effects.
        for (int i = 0; i < 2; i++) run(method, Math.min(tickets, 100), fields);
        long total = 0;
        for (int r = 0; r < repeats; r++) {
            long start = System.nanoTime();
            run(method, tickets, fields);
            total += System.nanoTime() - start;
        }
        return total / repeats;
    }

    private static void run(String method, int tickets, int fields) {
        int checksum = 0;
        for (int t = 0; t < tickets; t++) {
            String ticket;
            switch (method) {
                case "String +":
                    ticket = buildWithPlus(fields);
                    break;
                case "StringBuilder":
                    ticket = buildWithBuilder(fields);
                    break;
                default:
                    ticket = buildWithBuffer(fields);
            }
            checksum += ticket.length();
        }
        blackHole = checksum;
    }

    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        int[][] workloads = {
            {1, 5},          // short ticket
            {1000, 20},      // medium workload
            {10000, 50}      // larger workload
        };
        String[] methods = {"String +", "StringBuilder", "StringBuffer"};
        int repeats = 5;

        System.out.println("Q1 Ticket generation benchmark (average of " + repeats + " runs)");
        System.out.printf("%-16s %-12s %-12s %-15s%n", "Method", "Tickets", "Fields", "Average ms");
        for (int[] w : workloads) {
            for (String method : methods) {
                long nanos = measure(method, w[0], w[1], repeats);
                System.out.printf("%-16s %-12d %-12d %-15.3f%n",
                    method, w[0], w[1], nanos / 1_000_000.0);
            }
        }
        System.out.println();
        System.out.println("Approximate intermediate String objects for repeated +:");
        System.out.println("At least one new accumulated String per field append, in addition to field fragments.");
        System.out.println("StringBuilder/StringBuffer reduce repeated accumulated-String creation.");
        System.out.println("Note: exact allocation counts require a profiler; timings are machine-dependent.");
    }
}
