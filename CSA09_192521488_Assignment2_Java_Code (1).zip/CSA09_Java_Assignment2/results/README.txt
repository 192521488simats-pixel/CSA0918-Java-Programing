Save your own console outputs, raw timing data and screenshots in this folder.
Do not invent benchmark results.
