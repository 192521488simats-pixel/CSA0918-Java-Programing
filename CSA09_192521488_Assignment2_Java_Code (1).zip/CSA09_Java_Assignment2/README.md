# Programming in Java – Assignment 2 (CO2)

**Student name:** S. Hariharan  
**Register number:** 192521488  
**Java version:** Java 17 or later (the programs use standard Java APIs).

This project contains runnable Java examples for Q1–Q7 from the supplied assignment.

## Folder structure

- `Task01/` – String, StringBuilder and StringBuffer benchmark
- `Task02/` – ArrayList, LinkedList and ArrayDeque operation comparison
- `Task03/` – HashSet equality/hashCode contract demonstrations
- `Task04/` – HashMap, TreeMap and LinkedHashMap inventory comparison
- `Task05/` – Generic Leaderboard with Comparator
- `Task06/` – Emergency triage using PriorityQueue
- `Task07/` – Diagnose and redesign: ArrayList front insertion vs ArrayDeque
- `results/` – Place to save your own console output and measured data

## Compile and run

Open a terminal in this project folder. For each task, compile the Java file and run its class.

Example (Windows PowerShell / Command Prompt):

```text
cd Task01
javac TicketBenchmark.java
java TicketBenchmark
```

Repeat with the matching `.java` filename and class name in each task folder:

```text
javac PlaylistBenchmark.java
java PlaylistBenchmark

javac Attendance.java
java Attendance

javac PharmacyInventory.java
java PharmacyInventory

javac LeaderboardDemo.java
java LeaderboardDemo

javac Triage.java
java Triage

javac QueueRedesign.java
java QueueRedesign
```

If your terminal is in the project root, use `javac Task01/TicketBenchmark.java` and then
`java -cp Task01 TicketBenchmark` (repeat for each folder).

## Important execution / evidence note

The assignment requires predictions, experiments, repeated measurements, analysis and output
screenshots. The benchmark programs measure timings on the computer where they are executed.
**Do not submit invented timings.** Run each benchmark on your own laptop, save the actual
console output in `results/`, and take screenshots of your own executions. Timings vary with
processor, memory, Java version and background activity.

## Task notes

- Q1 measures three ticket-building techniques at three workload sizes. It reports average time
  across repeated runs and an approximate intermediate-string count for repeated concatenation.
- Q2 measures common playlist operations at three sizes. It uses separate test structures so the
  operations can be compared.
- Q3 first demonstrates a deliberately broken `equals`/`hashCode` implementation, then shows
  the corrected implementation. It also tests the effect of changing a hash-relevant field.
- Q4 compares map lookup and report generation. The reports are code-sorted and insertion-ordered.
- Q5 sorts a copied list with a reusable generic `Leaderboard<T>`.
- Q6 serves the lowest severity number first and preserves arrival order for equal severity.
- Q7 compares a simple original design with an ArrayDeque redesign for repeated front operations.

## Submission checklist

1. Run every program yourself and understand the code.
2. Add your actual output screenshots and raw measurements to `results/`.
3. Complete the written prediction, complexity, fairness and design-analysis sections required by
   the assignment PDF. The code alone is not the full 50-mark submission.
4. Create the GitHub repository using the required name:
   `CSA09-192521488-Assignment2`
5. Commit progressively (at least one commit per task), then share the repository link with faculty.
6. Add the working GitHub URL to your report and the assignment cover page.

## General complexity reminders

- Repeated immutable-string concatenation in a loop can copy an increasing amount of text;
  StringBuilder append is amortized O(1) per append and O(total output length) overall.
- ArrayList indexed access is O(1); insertion/removal near the front or middle is O(n).
- LinkedList indexed access is O(n); insertion/removal at a known node is O(1), but locating it is O(n).
- ArrayDeque offers amortized O(1) operations at both ends; it is not designed for indexed access.
- HashMap / HashSet operations are O(1) average under good hash distribution; TreeMap is O(log n).
- PriorityQueue insertion and removal of the head are O(log n); peeking is O(1).
- Comparison sorting is O(n log n).
