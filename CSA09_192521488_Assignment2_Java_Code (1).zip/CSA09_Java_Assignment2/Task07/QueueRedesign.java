import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

public class QueueRedesign {
    private static volatile int sink;

    private static long timeNanos(Runnable r) {
        long start = System.nanoTime();
        r.run();
        return System.nanoTime() - start;
    }

    private static void originalArrayList(int n, int operations) {
        List<Integer> queue = new ArrayList<>();
        for (int i = 0; i < n; i++) queue.add(i);
        for (int i = 0; i < operations; i++) {
            queue.add(0, -i);
            queue.remove(0);
        }
        sink = queue.size();
    }

    private static void redesignedArrayDeque(int n, int operations) {
        Deque<Integer> queue = new ArrayDeque<>();
        for (int i = 0; i < n; i++) queue.addLast(i);
        for (int i = 0; i < operations; i++) {
            queue.addFirst(-i);
            queue.removeFirst();
        }
        sink = queue.size();
    }

    public static void main(String[] args) {
        int[] sizes = {1000, 10000, 50000};
        int operations = 5000;
        int repeats = 3;

        System.out.println("Q7 Original vs redesigned queue");
        System.out.println("Operation pattern: repeated add-front then remove-front.");
        System.out.printf("%-12s %-18s %-18s%n", "Initial size", "ArrayList ms", "ArrayDeque ms");

        for (int n : sizes) {
            long originalTotal = 0;
            long redesignedTotal = 0;
            for (int r = 0; r < repeats; r++) {
                originalTotal += timeNanos(() -> originalArrayList(n, operations));
                redesignedTotal += timeNanos(() -> redesignedArrayDeque(n, operations));
            }
            System.out.printf("%-12d %-18.3f %-18.3f%n", n,
                originalTotal / repeats / 1e6,
                redesignedTotal / repeats / 1e6);
        }

        System.out.println("\nDiagnosis: ArrayList shifts many elements for each front insertion/removal.");
        System.out.println("Redesign: ArrayDeque uses a resizable circular array and supports both ends.");
        System.out.println("Expected: ArrayDeque front operations are amortized O(1), while ArrayList front operations are O(n).");
        System.out.println("Trade-off: ArrayDeque does not provide O(1) indexed access; retain ArrayList when random access dominates.");
    }
}
