import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class Attendance {
    // Deliberately broken: equals is based on regNo, but hashCode uses Object's identity hash.
    static class BrokenStudent {
        String regNo;
        String name;
        BrokenStudent(String regNo, String name) { this.regNo = regNo; this.name = name; }
        @Override public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof BrokenStudent)) return false;
            return regNo.equals(((BrokenStudent) o).regNo);
        }
    }

    static class Student {
        private final String regNo;
        private final String name;
        Student(String regNo, String name) { this.regNo = regNo; this.name = name; }
        @Override public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Student)) return false;
            Student other = (Student) o;
            return regNo.equals(other.regNo);
        }
        @Override public int hashCode() { return Objects.hash(regNo); }
        @Override public String toString() { return regNo + " " + name; }
    }

    static class MutableStudent {
        String regNo;
        MutableStudent(String regNo) { this.regNo = regNo; }
        @Override public boolean equals(Object o) {
            return o instanceof MutableStudent && regNo.equals(((MutableStudent) o).regNo);
        }
        @Override public int hashCode() { return Objects.hash(regNo); }
    }

    public static void main(String[] args) {
        Set<BrokenStudent> broken = new HashSet<>();
        broken.add(new BrokenStudent("192311001", "Arun"));
        broken.add(new BrokenStudent("192311002", "Divya"));
        broken.add(new BrokenStudent("192311001", "Arun"));
        System.out.println("Broken class unique students (may expose duplicate): " + broken.size());

        Set<Student> fixed = new HashSet<>();
        fixed.add(new Student("192311001", "Arun"));
        fixed.add(new Student("192311002", "Divya"));
        fixed.add(new Student("192311001", "Arun"));
        System.out.println("Corrected class unique students: " + fixed.size());

        Set<MutableStudent> mutableSet = new HashSet<>();
        MutableStudent m = new MutableStudent("ID-1");
        mutableSet.add(m);
        System.out.println("Mutable object found before change: " + mutableSet.contains(m));
        m.regNo = "ID-2";
        System.out.println("Mutable object found after change: " + mutableSet.contains(m));
        System.out.println("Avoid changing fields used by equals/hashCode while an object is in a hash collection.");
    }
}
