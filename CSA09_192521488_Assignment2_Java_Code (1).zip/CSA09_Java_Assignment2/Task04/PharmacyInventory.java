import java.util.*;

public class PharmacyInventory {
    private static volatile int sink;

    private static long timeNanos(Runnable r) {
        long start = System.nanoTime(); r.run(); return System.nanoTime() - start;
    }

    public static void main(String[] args) {
        int[] sizes = {1000, 10000, 50000};
        Random random = new Random(42);

        for (int n : sizes) {
            Map<String, Integer> hash = new HashMap<>();
            Map<String, Integer> tree = new TreeMap<>();
            Map<String, Integer> linked = new LinkedHashMap<>();

            for (int i = 0; i < n; i++) {
                String code = String.format("MED%06d", i);
                int stock = random.nextInt(500);
                hash.put(code, stock);
                tree.put(code, stock);
                linked.put(code, stock);
            }

            String[] lookups = new String[100000];
            for (int i = 0; i < lookups.length; i++)
                lookups[i] = String.format("MED%06d", i % n);

            long hashGet = timeNanos(() -> { int sum=0; for (String k: lookups) sum += hash.get(k); sink=sum; });
            long treeGet = timeNanos(() -> { int sum=0; for (String k: lookups) sum += tree.get(k); sink=sum; });
            long linkedGet = timeNanos(() -> { int sum=0; for (String k: lookups) sum += linked.get(k); sink=sum; });

            long treeReport = timeNanos(() -> { int sum=0; for (Map.Entry<String,Integer> e: tree.entrySet()) sum += e.getValue(); sink=sum; });
            long linkedReport = timeNanos(() -> { int sum=0; for (Map.Entry<String,Integer> e: linked.entrySet()) sum += e.getValue(); sink=sum; });
            long hashSortReport = timeNanos(() -> {
                List<String> keys = new ArrayList<>(hash.keySet());
                Collections.sort(keys);
                int sum=0; for (String k: keys) sum += hash.get(k); sink=sum;
            });

            System.out.printf("%nMedicines: %d%n", n);
            System.out.printf("100,000 lookups: HashMap %.3f ms | TreeMap %.3f ms | LinkedHashMap %.3f ms%n",
                hashGet/1e6, treeGet/1e6, linkedGet/1e6);
            System.out.printf("Code-order report: TreeMap %.3f ms | HashMap + sort %.3f ms%n",
                treeReport/1e6, hashSortReport/1e6);
            System.out.printf("Insertion-order report: LinkedHashMap %.3f ms%n", linkedReport/1e6);
            System.out.println("First code in TreeMap report: " + tree.keySet().iterator().next());
            System.out.println("First code in insertion-order report: " + linked.keySet().iterator().next());
        }
        System.out.println("\nHashMap: average O(1) lookup, no order guarantee.");
        System.out.println("TreeMap: O(log n) lookup/update, keys kept sorted.");
        System.out.println("LinkedHashMap: average O(1) lookup, preserves insertion order.");
    }
}
