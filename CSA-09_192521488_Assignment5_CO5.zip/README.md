# Java Assignment 5 – CO5: Data Persistence Engineering

This repository structure is based on **Assignment CO5 Java.docx.pdf**. It contains individual folders for Tasks A1–A5 (design/pseudocode) and B1–B4 (implementation).

## Requirements
- Java 11 or later (Java 11 is needed for `Files.readString`/`writeString` in some tasks).
- For JDBC tasks B2–B4, a MySQL server and MySQL Connector/J driver are required.
- Configure database credentials using environment variables:
  - `DB_URL` (example: `jdbc:mysql://localhost:3306/assignment5`)
  - `DB_USER`
  - `DB_PASSWORD`
- Do not put real passwords into source code or commit them to GitHub.

## Folders
- `TaskA1` – text/binary record layout and pseudocode
- `TaskA2` – buffered I/O design and complexity notes
- `TaskA3` – generic DAO interface and student mapping
- `TaskA4` – serialization design notes and example classes
- `TaskA5` – JDBC transaction and PreparedStatement notes
- `TaskB1` – completed PassStore and line-count benchmark
- `TaskB2` – unsafe vs safe login query demonstration (use only a local test database)
- `TaskB3` – transactional batch loader and SQL schema
- `TaskB4` – file-to-database migration and DatabaseMetaData inspection

## Compile/run examples
```bash
cd TaskB1
javac PassStore.java
java PassStore
java LineCounterBenchmark
```

For JDBC files, add the MySQL Connector/J JAR to the classpath. Example on Windows:
```bat
javac -cp ".;mysql-connector-j-9.x.x.jar" PassLoader.java
java -cp ".;mysql-connector-j-9.x.x.jar" PassLoader
```
On Linux/macOS, use `:` instead of `;` in the classpath.

Before running JDBC tasks, create a local test database and execute `TaskB3/schema.sql`. Then set `DB_URL`, `DB_USER`, and `DB_PASSWORD`.

## Important submission notes
- The assignment requires your own actual measurements for 1 MB, 10 MB, 50 MB, and 1,000 / 10,000 / 100,000 records. Do not report invented timings as measured results.
- Run each program yourself, save screenshots of the actual output, and add your name/register number and GitHub URL.
- The A tasks require written design/pseudocode and reasoning as well as code. Java code alone does not replace the required pseudocode.
