import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Demonstrates unsafe concatenation vs parameter binding.
 * Run only against a local disposable assignment database.
 * Uses environment variables DB_URL, DB_USER, DB_PASSWORD.
 */
public class LoginSafetyDemo {
    static boolean unsafeLogin(Connection con, String id, String pwd) throws SQLException {
        String sql = "SELECT COUNT(*) FROM demo_users WHERE id='" + id + "' AND pwd='" + pwd + "'";
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            return rs.next() && rs.getInt(1) > 0;
        }
    }

    static boolean safeLogin(Connection con, String id, String pwd) throws SQLException {
        String sql = "SELECT COUNT(*) FROM demo_users WHERE id=? AND pwd=?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, id);
            ps.setString(2, pwd);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    public static void main(String[] args) throws Exception {
        String url = System.getenv("DB_URL");
        String user = System.getenv("DB_USER");
        String password = System.getenv("DB_PASSWORD");
        if (url == null || user == null || password == null) {
            System.out.println("Set DB_URL, DB_USER and DB_PASSWORD for a local test database.");
            return;
        }
        try (Connection con = java.sql.DriverManager.getConnection(url, user, password);
             Statement st = con.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS demo_users (id VARCHAR(100), pwd VARCHAR(100))");
            st.executeUpdate("DELETE FROM demo_users");
            st.executeUpdate("INSERT INTO demo_users(id,pwd) VALUES ('student','correct-password')");

            String craftedId = "student' OR '1'='1' -- ";
            String invalidPassword = "wrong";
            System.out.println("Unsafe accepts crafted input: "
                    + unsafeLogin(con, craftedId, invalidPassword));
            System.out.println("PreparedStatement accepts crafted input: "
                    + safeLogin(con, craftedId, invalidPassword));
            System.out.println("Normal valid login via safe query: "
                    + safeLogin(con, "student", "correct-password"));
        }
    }
}
