import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Reads simple five-field pass CSV (passId,regNo,name,routeNo,amount),
 * validates rows, inserts valid rows in one transaction, reports invalid rows,
 * and prints database metadata.
 */
public class MigratePasses {
    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.out.println("Usage: java MigratePasses <input-csv-file>");
            return;
        }
        String url = System.getenv("DB_URL");
        String user = System.getenv("DB_USER");
        String password = System.getenv("DB_PASSWORD");
        if (url == null || user == null || password == null) {
            System.out.println("Set DB_URL, DB_USER and DB_PASSWORD.");
            return;
        }
        List<String[]> valid = new ArrayList<>();
        int invalid = 0;
        try (BufferedReader reader = Files.newBufferedReader(Path.of(args[0]), StandardCharsets.UTF_8)) {
            String line;
            int lineNo = 0;
            while ((line = reader.readLine()) != null) {
                lineNo++;
                String[] f = line.split(",", -1);
                try {
                    if (f.length != 5) throw new IllegalArgumentException("expected 5 fields");
                    if (f[0].isBlank() || f[1].isBlank() || f[2].isBlank()) throw new IllegalArgumentException("required field missing");
                    Integer.parseInt(f[3]);
                    double amount = Double.parseDouble(f[4]);
                    if (!Double.isFinite(amount) || amount < 0) throw new IllegalArgumentException("invalid amount");
                    valid.add(f);
                } catch (RuntimeException ex) {
                    invalid++;
                    System.err.println("Rejected line " + lineNo + ": " + ex.getMessage() + " | " + line);
                }
            }
        }

        try (Connection con = DriverManager.getConnection(url, user, password)) {
            DatabaseMetaData md = con.getMetaData();
            System.out.println("Database: " + md.getDatabaseProductName());
            System.out.println("Database version: " + md.getDatabaseProductVersion());
            System.out.println("Driver: " + md.getDriverName() + " " + md.getDriverVersion());
            System.out.println("Tables:");
            try (var rs = md.getTables(con.getCatalog(), null, "%", new String[]{"TABLE"})) {
                while (rs.next()) System.out.println(" - " + rs.getString("TABLE_NAME"));
            }
            String sql = "INSERT INTO bus_pass(pass_id,reg_no,name,route_no,amount) VALUES (?,?,?,?,?)";
            boolean old = con.getAutoCommit();
            con.setAutoCommit(false);
            int inserted = 0;
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                int pending = 0;
                for (String[] f : valid) {
                    ps.setString(1, f[0]);
                    ps.setString(2, f[1]);
                    ps.setString(3, f[2]);
                    ps.setInt(4, Integer.parseInt(f[3]));
                    ps.setDouble(5, Double.parseDouble(f[4]));
                    ps.addBatch();
                    pending++;
                    inserted++;
                    if (pending == 1000) { ps.executeBatch(); pending = 0; }
                }
                if (pending > 0) ps.executeBatch();
                con.commit();
            } catch (SQLException | RuntimeException ex) {
                con.rollback();
                throw ex;
            } finally {
                con.setAutoCommit(old);
            }
            System.out.println("Valid rows: " + valid.size());
            System.out.println("Rejected rows: " + invalid);
            System.out.println("Rows submitted for migration: " + inserted);
        }
    }
}
