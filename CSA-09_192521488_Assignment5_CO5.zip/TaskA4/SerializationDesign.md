# A4 – What Should Be Serialized?

Persist durable hostel/room/resident data, but do not serialize live resources such as JDBC `Connection`, sockets, open streams, or UI objects. Mark the connection `transient`; passwords should generally not be persisted in plaintext at all. Prefer storing a salted password hash in a secure database.

When `Hostel` is serialized, Java traverses the reachable object graph and serializes referenced objects that are serializable. Every non-transient reachable object must support serialization or `NotSerializableException` can occur.

Declare an explicit `serialVersionUID`. When a compatible class adds a field, old streams generally deserialize with the new field set to its default value (null/0/false). Incompatible changes or mismatched `serialVersionUID` can produce `InvalidClassException`. Validate and migrate old data.

CSV/JSON are more interoperable and easier to inspect, but require explicit mapping/escaping and schema-version handling. Java serialization is convenient for object graphs but is Java-specific and can be unsafe for untrusted data. For n residents, save/load is generally O(n); memory depends on whether the whole graph/document is built in memory.
