# A2 – Don’t Read What You Don’t Need

A 50 MB file read one byte at a time makes approximately 52,428,800 data-level `read()` calls, plus an EOF call, if 50 MB means 50 × 1,048,576 bytes. If MB is decimal, it is 50,000,000 data calls plus EOF. Small reads create substantial method/system-call overhead.

Use `BufferedInputStream` or a byte array buffer (for example, 8 KiB or 64 KiB), process chunks and count newline bytes. This reduces underlying I/O operations to roughly file-size / buffer-size, plus a final EOF read. Time complexity is O(n); extra memory is O(b), where b is buffer size.

Buffering may help little when data is already in memory/cache, the stream already buffers, or processing time dominates I/O. `Files.readAllLines()` is convenient but holds all decoded lines in memory: O(n) memory, potentially much more than the raw file size. Use it for small files, not a 50 MB log when memory is constrained.
