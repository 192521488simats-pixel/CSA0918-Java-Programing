// Example design for A3. Save this file as Design.java and run with Java 8+.
import java.util.List;
import java.util.Optional;

interface Dao<T, K> {
    T insert(T value);
    Optional<T> findById(K id);
    List<T> findAll();
    boolean update(T value);
    boolean delete(K id);
}

class Student {
    private final long id;
    private final String name;
    private final String registerNumber;

    Student(long id, String name, String registerNumber) {
        this.id = id;
        this.name = name;
        this.registerNumber = registerNumber;
    }
    long getId() { return id; }
    String getName() { return name; }
    String getRegisterNumber() { return registerNumber; }
}

// Mapping example: Student.id -> student.id (primary key),
// Student.name -> student.name, Student.registerNumber -> student.register_no.
// A real StudentDao would receive a shared DataSource and use PreparedStatement.
public class Design {
    public static void main(String[] args) {
        System.out.println("Dao<T,K> separates common CRUD operations from table-specific SQL.");
        System.out.println("Student fields map to student(id PRIMARY KEY, name, register_no).");
    }
}
