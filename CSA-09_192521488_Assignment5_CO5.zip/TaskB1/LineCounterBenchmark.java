import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public class LineCounterBenchmark {
    static long countLinesUnbuffered(Path file) throws IOException {
        long lines = 0;
        try (InputStream in = Files.newInputStream(file)) {
            int value;
            while ((value = in.read()) != -1) if (value == '\n') lines++;
        }
        return lines;
    }

    static long countLinesBuffered(Path file) throws IOException {
        long lines = 0;
        byte[] buffer = new byte[64 * 1024];
        try (InputStream in = new BufferedInputStream(Files.newInputStream(file), buffer.length)) {
            int count;
            while ((count = in.read(buffer)) != -1) {
                for (int i = 0; i < count; i++) if (buffer[i] == '\n') lines++;
            }
        }
        return lines;
    }

    public static void main(String[] args) throws IOException {
        for (int mb : new int[]{1, 10, 50}) {
            Path file = Files.createTempFile("line-count-" + mb, ".txt");
            byte[] block = new byte[8192];
            for (int i = 0; i < block.length; i++) block[i] = (i % 80 == 79) ? (byte)'\n' : (byte)'x';
            long target = (long) mb * 1024 * 1024;
            try (var out = Files.newOutputStream(file, StandardOpenOption.TRUNCATE_EXISTING)) {
                long written = 0;
                while (written < target) {
                    int amount = (int)Math.min(block.length, target - written);
                    out.write(block, 0, amount);
                    written += amount;
                }
            }
            long start = System.nanoTime();
            long unbufferedLines = countLinesUnbuffered(file);
            long unbufferedMs = (System.nanoTime() - start) / 1_000_000;
            start = System.nanoTime();
            long bufferedLines = countLinesBuffered(file);
            long bufferedMs = (System.nanoTime() - start) / 1_000_000;
            System.out.printf("%d MB: unbuffered=%d lines, %d ms; buffered=%d lines, %d ms%n",
                    mb, unbufferedLines, unbufferedMs, bufferedLines, bufferedMs);
            Files.deleteIfExists(file);
        }
        System.out.println("Record the timings from your own machine; timings vary by hardware and cache.");
    }
}
