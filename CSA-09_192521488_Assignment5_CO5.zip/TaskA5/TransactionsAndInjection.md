# A5 – Correctness and Safety

## Wallet transfer pseudocode
1. Obtain a database connection.
2. Set auto-commit false.
3. Read/lock both wallet rows and verify the source balance is at least ₹500.
4. Update source wallet: balance = balance - 500; require exactly one row updated.
5. Update destination wallet: balance = balance + 500; require exactly one row updated.
6. Commit only after both updates succeed.
7. If any operation fails, rollback and report failure.
8. Restore the previous auto-commit setting and close resources.

A single transaction prevents a crash between updates from leaving only one side committed, assuming the database tables use a transactional engine.

## SQL injection
String concatenation allows input to change SQL syntax. An attacker may submit a crafted ID/password containing quote characters and a Boolean expression or SQL comment so the password predicate is bypassed. Do not rely on escaping or regex validation. Use a `PreparedStatement` with `WHERE id = ? AND pwd_hash = ?` and bind values through setters. Store password hashes, not plaintext passwords.

Two auto-commit updates can leave money lost/created if the process fails between them. A transaction adds some coordination/logging overhead but preserves atomicity and correctness.
