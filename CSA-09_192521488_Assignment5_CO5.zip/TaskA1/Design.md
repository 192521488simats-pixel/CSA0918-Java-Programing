# A1 – Design a File Format

## Text record layout
Use one UTF-8 record per line with seven fields in this order:
`passId,registerNo,name,routeNo,boardingStop,validUntil,amountPaid`

Because names/stops may contain commas or newlines, a production implementation should use a proper CSV library with quoting/escaping. For a simple classroom format, reject commas/newlines in fields or encode them consistently (for example, backslash escaping). Validate the exact field count, numeric route/amount and date format on read.

## Binary record layout
Use `DataOutputStream` in this field order:
- `writeUTF(passId)`
- `writeUTF(registerNo)`
- `writeUTF(name)`
- `writeInt(routeNo)`
- `writeUTF(boardingStop)`
- `writeUTF(validUntil)` (ISO date)
- `writeDouble(amountPaid)`

`writeUTF` stores a length prefix and modified UTF-8 data, so string fields are variable-length rather than fixed-size.

## Pseudocode – add
1. Validate required fields and formats.
2. Open the UTF-8 file in append mode using `BufferedWriter`.
3. Encode/escape fields according to the file format.
4. Write one complete record and a newline.
5. Flush/close using try-with-resources.
6. For stronger crash safety, write to a temporary file and atomically replace the original, or use a journal.

## Pseudocode – find by pass ID
1. If the file does not exist, return NOT_FOUND or a clear missing-file result.
2. Open `BufferedReader`.
3. Read each line until EOF.
4. Parse and validate the record; skip/report malformed lines.
5. If field 1 equals the requested ID, return the parsed record.
6. If EOF is reached, return NOT_FOUND.
7. Close the reader.

## Pseudocode – list by route
1. Open `BufferedReader`.
2. Read each line until EOF.
3. Parse/validate; report and skip malformed records.
4. If the route field equals the requested route, append the record to the result.
5. Return the result and close the reader.

## Damaged/missing/incomplete data
A missing file should be handled distinctly from a valid empty file. A damaged line should be logged with its line number and skipped or quarantined. A power failure during append can leave a partial final line; validate every record and consider temporary-file replacement, checksums or a journal for stronger integrity.

## Alternative: RandomAccessFile
A fixed-size record can be located by seeking to `index * recordSize` in O(1), but searching by ID is still O(n) without an index because each record must be checked. Fixed-size padded fields waste space when values are shorter than their allocated widths. A separate ID-to-offset index can support faster lookups.
