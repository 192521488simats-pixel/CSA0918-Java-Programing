import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** Transactional batch insert. Each String[] is {passId, regNo, name, routeNo, amount}. */
public class PassLoader {
    public static int loadAll(Connection con, List<String[]> passes) throws SQLException {
        String sql = "INSERT INTO bus_pass(pass_id, reg_no, name, route_no, amount) VALUES (?, ?, ?, ?, ?)";
        boolean oldAutoCommit = con.getAutoCommit();
        con.setAutoCommit(false);
        int total = 0;
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            int pending = 0;
            for (String[] p : passes) {
                if (p == null || p.length != 5) throw new IllegalArgumentException("Each pass must contain 5 fields");
                ps.setString(1, p[0]);
                ps.setString(2, p[1]);
                ps.setString(3, p[2]);
                ps.setInt(4, Integer.parseInt(p[3]));
                ps.setDouble(5, Double.parseDouble(p[4]));
                ps.addBatch();
                pending++;
                total++;
                if (pending == 1000) {
                    ps.executeBatch();
                    pending = 0;
                }
            }
            if (pending > 0) ps.executeBatch();
            con.commit();
            return total;
        } catch (SQLException | RuntimeException e) {
            try { con.rollback(); } catch (SQLException rollbackError) { e.addSuppressed(rollbackError); }
            throw e;
        } finally {
            con.setAutoCommit(oldAutoCommit);
        }
    }

    public static void main(String[] args) throws Exception {
        String url = System.getenv("DB_URL");
        String user = System.getenv("DB_USER");
        String password = System.getenv("DB_PASSWORD");
        if (url == null || user == null || password == null) {
            System.out.println("Set DB_URL, DB_USER and DB_PASSWORD, then run schema.sql first.");
            return;
        }
        List<String[]> sample = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            sample.add(new String[]{"P" + i, "REG" + i, "Student" + i, "12", "4500.00"});
        }
        try (Connection con = DriverManager.getConnection(url, user, password)) {
            System.out.println("Rows loaded: " + loadAll(con, sample));
        }
    }
}
