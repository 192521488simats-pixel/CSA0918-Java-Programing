# Assignment 4 – Written Answers (CO4)

## Task 1 – GUI Design Review

### 1.1 Design deficiencies
1. **UI and business logic are mixed:** the listener validates, connects to the database and performs payment. This makes the window difficult to test and maintain.
2. **Incorrect String comparison:** `==` compares object references; use `"Pay".equals(e.getActionCommand())` or separate listeners.
3. **No input validation:** empty registration numbers, non-numeric amounts, zero and negative amounts can cause errors or invalid records.
4. **Database work blocks the event-dispatch thread:** slow database access freezes repainting and user interaction.
5. **`Thread.sleep(3000)` freezes the UI:** the window appears unresponsive for three seconds.
6. **No useful feedback:** `System.out.println` is not visible to the user; show a status label or dialog.
7. **Receipt button is not implemented:** the `else` branch clears fields for both Clear and Receipt.
8. **SQL injection risk:** concatenating user values into SQL is unsafe; use `PreparedStatement`.
9. **Resources are not closed:** connection and statement may remain open; use try-with-resources.
10. **Exceptions are not handled:** JDBC exceptions and interruption can prevent compilation or crash the handler.
11. **No window-close handling:** the application should dispose resources and close predictably.

### 1.2 Repair
`FeeWindow` only collects input and displays status. `FeeService` validates the registration number and amount and writes the payment with a parameterised `PreparedStatement`. Separate listeners are registered for Pay, Clear and Receipt. The source code is in `Task01/`.

**Production improvement:** move the database call to `SwingWorker` so it does not run on the event-dispatch thread. A real bank confirmation should be asynchronous and should not be simulated with `sleep()`.

### 1.3 Design defence (under 100 words)
The redesigned window has only presentation responsibilities, while FeeService contains validation and payment rules. The service can be tested without opening a GUI, and the window can be changed without rewriting database logic. Prepared statements protect SQL parameters, and try-with-resources closes database objects reliably. Separate listeners make each button action clear. This separation reduces duplication and makes defects easier to locate.

### Alternative listener and complexity
With one shared listener and an `if–else` chain, dispatch checks up to k action commands, so the selection work is O(k) in the worst case. With one listener per button, the event source is already connected to its action, giving O(1) selection work. Creating k listener objects requires O(k) additional space. Both approaches still perform the actual button action after dispatch.

## Task 2 – Requirement to Event-Driven Design
See `Task02/Task02_Design.md` for the event-source table, component hierarchy, pseudocode and event trace.

## Task 3 – Campus Library Search Screen

### 3.1 Layout manager choices
- **Frame:** `BorderLayout`; it provides north, centre and south regions.
- **Top panel:** nested `BorderLayout`; title in NORTH and search row in SOUTH.
- **Search row:** `FlowLayout`; controls remain at their preferred sizes.
- **Results:** `JScrollPane` containing `JTable` in CENTER; the centre receives extra space when the frame grows.
- **Bottom panel:** `BorderLayout` with the Prev/Next/Reserve row in NORTH and status in SOUTH. The button row uses `FlowLayout`.

### 3.2 Nested structure
```text
JFrame (BorderLayout)
├── JPanel top (BorderLayout)
│   ├── JLabel title (NORTH)
│   └── JPanel searchRow (FlowLayout, SOUTH)
├── JScrollPane + JTable (CENTER)
└── JPanel south (BorderLayout)
    ├── JPanel buttons (FlowLayout, NORTH)
    └── JLabel status (SOUTH)
```

### 3.3 Implementation
Run `Task03/LibrarySearchScreen.java`. It uses sample in-memory book rows to demonstrate the requested screen and event handling. It is not connected to a library database because no database schema was supplied in the assignment.

### 3.4 Resizing test
Run the screen and capture three screenshots yourself: (1) minimum-sized window, (2) normal 760×500 window, and (3) maximised window. The centre results table should expand; search controls and bottom buttons should retain preferred sizes. Add the screenshots to the repository.

### Alternative layout and complexity
`GridBagLayout` can create flexible, constraint-based rows and columns, but requires more layout constraints and more calculation during layout. Absolute positioning with `setLayout(null)` and `setBounds` has little layout-manager computation but does not adapt automatically to resizing, fonts or display scaling. Nested BorderLayout/FlowLayout uses several small panels (O(p) container space for p panels) and provides robust resizing. Layout computation is generally O(c) in the number of child components for these simple managers; exact timing depends on the component hierarchy and platform.

## Task 4 – Event-Handling Forensics

### 4.1 Defect
The method is written `mouseclicked`, but Java's `MouseListener` callback is case-sensitive and must be `mouseClicked(MouseEvent e)`. Therefore the method does not override the listener callback and is never invoked. The label is also never updated in the original code.

### 4.2 Failing interaction
Click several times to draw dots, minimise the window, then restore it. The dots disappear because the original code draws directly using `getGraphics()` only once. Repainting does not know how to recreate those marks.

### 4.3 Repair
The completed `Task04/DrawPad.java` stores each click as a `Point`, updates the label, calls `repaint()`, and draws all saved points in `paint(Graphics)`. This makes drawing persistent across repainting.

### 4.4 `@Override`
If `@Override` is placed above the misspelled `mouseclicked` method, the compiler reports that the method does not override or implement a method from a supertype. It catches the spelling/capitalisation error before execution.

### Complete-the-code TODOs
- TODO 1: `points.add(e.getPoint()); status.setText("Clicks: " + points.size()); repaint();`
- TODO 2: loop through `points` and call `g.fillOval(p.x - 3, p.y - 3, 6, 6);`

### Alternative BufferedImage
An off-screen `BufferedImage` stores the drawing as pixels. Each click draws into the image; `paint()` copies the image to the screen. Repainting is approximately O(width × height) for a full image copy, independent of click count, while the point-list approach redraws O(n) points for n clicks. The point list uses O(n) space; the image uses O(width × height) pixels (four bytes per pixel for common ARGB storage).

## Task 5 – Event-Handling Styles

Four implementations are supplied in `Task05/`: frame implements ActionListener, named inner class, anonymous inner class and lambda. Each handles the Convert button and Enter key and displays the result in a dialog. The lambda complete-code version uses one `ActionListener` object registered with both controls.

### Comparison
| Style | Readability | Access to frame fields | Reuse | Ease of change |
|---|---|---|---|---|
| Frame implements ActionListener | Simple for tiny frame; mixes roles | Direct | Low; frame itself is listener | Moderate |
| Named inner class | Clear when handler has substantial logic | Direct | Good; can be reused | Good |
| Anonymous inner class | Keeps short handler near registration | Direct | Limited outside that location | Moderate |
| Lambda | Concise for a short functional action | Directly through enclosing instance | Reuse by storing listener in a variable | Very easy for small actions |

For a large application, use a separate named handler or shared Swing `Action` because it separates responsibilities and can be reused by buttons, menu items and keyboard shortcuts.

### Requirement change
The implementations register the same handler with both the button and text field, so Enter support requires only one additional listener registration. The handler displays a dialog as well as updating the result label. A shared `Action` object is preferable when several controls and keyboard shortcuts must trigger the same operation.

### Alternative method reference / Action
A method reference `e -> convert()` can be replaced by `e -> convert()` or a compatible method reference only if the method signature matches the listener signature; `this::convert` (no arguments) is not directly compatible with `ActionListener.actionPerformed(ActionEvent)`. A wrapper lambda `e -> convert()` is valid. A Swing `Action` can be shared by a button, menu item and key binding, reducing duplicated listener logic. One shared action object uses O(1) action-object space for any number of triggers; each separate listener object uses O(k) space for k triggers.

## Task 6 – Campus Event Registration Application

### Stage 1: users, screens, data and rules
- **Student:** enters student ID, name and selected event.
- **Committee member:** views, filters and exports registrations.
- **Screens:** registration form and registration table in one Swing frame; validation/database errors appear in dialogs.
- **Data:** registration ID, student ID, student name, event name and timestamp.
- **Rules:** required fields; valid ID format; a student may register only once for a given event; the database enforces uniqueness.

Testable requirements:
1. Empty ID, name or event must be rejected with a clear message.
2. A valid registration must be saved and appear in the table.
3. A repeated student ID + event combination must be rejected.
4. Filtering must show only the selected event.
5. The table must load in pages of 50 rows.
6. Database loading must not freeze the Swing window.
7. The current page can be exported as CSV.

### Stage 2: screen and event flow
```text
Launch → Event Registration Frame
             ├── Register → Validate → Insert to DB
             │                 ├── Success dialog/status → Refresh page
             │                 └── Invalid/duplicate → Error dialog
             ├── Filter → Load selected page → JTable
             ├── Previous / Next → Load page → JTable
             ├── Export CSV → Save File dialog → CSV file
             └── File > Exit → Confirm close → Dispose
```
The application has a `JMenuBar` with File → Refresh and File → Exit.

### Stage 3: critical decisions
- Validate required fields and student ID format in `RegistrationService`.
- Enforce duplicate prevention with a database `UNIQUE(student_id, event_name)` constraint; application-side checking alone is not sufficient under concurrent requests.
- Use `PreparedStatement` for all SQL parameters.
- Keep database work in `SwingWorker.doInBackground()`; update the JTable and status in `done()` on the event-dispatch thread.

### Stage 4: class structure
```text
EventRegistrationApp (JFrame / UI)
       |
       v
RegistrationService (validation and business rules)
       |
       v
RegistrationDAO (JDBC queries)
       |
       v
DB (connection factory) → MySQL
Registration (data model)
```

Register pseudocode:
```text
PROCEDURE register
    read studentId, studentName, eventName
    validate all fields
    IF invalid THEN show validation message and RETURN
    run service.register in background worker
    IF database unique constraint rejects row THEN show duplicate message
    ELSE show success and refresh first page
END PROCEDURE
```

Filter pseudocode:
```text
PROCEDURE filterRegistrations
    selectedEvent ← filterCombo.getSelectedItem()
    page ← 0
    start SwingWorker
        rows ← DAO.findPage(selectedEvent, pageSize, page × pageSize)
    when worker completes
        clear JTable model
        add each returned row
        update status label
END PROCEDURE
```

### Stage 5: implementation and test cases
Run `Task06/schema.sql`, set database credentials in `Task06/DB.java`, add MySQL Connector/J, then run `Task06.EventRegistrationApp`.

| Test | Input | Expected result |
|---|---|---|
| Normal | Valid student ID, name and event | Registration saved and shown in table |
| Invalid | Empty name or invalid ID | Clear validation message; no row inserted |
| Duplicate | Same student ID and event again | Unique constraint rejects it; duplicate message shown |
| Filter | Choose one event | Only that event's registrations appear |
| Paging | More than 50 rows | Previous/Next loads pages without blocking UI |

### Alternative: load all 100,000 rows at once
Loading all rows requires transferring and retaining 100,000 records and table objects in memory, so memory is O(N) and startup loading time is O(N) plus database/network overhead. The window may freeze if the query and model update occur on the event-dispatch thread. With page size P, each request transfers O(P) rows and the visible table uses O(P) memory; the database still performs work to locate the requested offset, and very large offsets may become slower. `SwingWorker` keeps network/database waiting off the UI thread, improving responsiveness. For very large datasets, keyset pagination can be more efficient than large OFFSET values.
