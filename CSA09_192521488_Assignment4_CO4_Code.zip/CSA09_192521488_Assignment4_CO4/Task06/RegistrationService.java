package Task06;

import java.sql.SQLException;
import java.util.List;

public class RegistrationService {
    private final RegistrationDAO dao = new RegistrationDAO();

    public void register(String studentId, String studentName, String eventName) throws Exception {
        if (studentId == null || !studentId.trim().matches("[A-Za-z0-9]{3,20}"))
            throw new IllegalArgumentException("Enter a valid student ID (3–20 letters/digits).");
        if (studentName == null || studentName.trim().isEmpty())
            throw new IllegalArgumentException("Student name is required.");
        if (eventName == null || eventName.trim().isEmpty() || "Select event".equals(eventName))
            throw new IllegalArgumentException("Select an event.");
        try {
            dao.insert(studentId.trim(), studentName.trim(), eventName);
        } catch (SQLException ex) {
            if ("23000".equals(ex.getSQLState()))
                throw new IllegalArgumentException("This student is already registered for this event.");
            throw ex;
        }
    }

    public List<Registration> getPage(String event, int limit, int offset) throws SQLException {
        return dao.findPage(event, limit, offset);
    }
}
