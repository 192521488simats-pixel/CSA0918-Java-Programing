package Task06;

import java.awt.*;
import java.awt.event.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class EventRegistrationApp extends JFrame {
    private static final int PAGE_SIZE = 50;
    private final JTextField studentId = new JTextField(12);
    private final JTextField studentName = new JTextField(16);
    private final JComboBox<String> event = new JComboBox<>(
            new String[]{"Select event", "Cultural Fest", "Technical Symposium", "Sports Meet"});
    private final JComboBox<String> filter = new JComboBox<>(
            new String[]{"All", "Cultural Fest", "Technical Symposium", "Sports Meet"});
    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"ID", "Student ID", "Student Name", "Event"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JLabel status = new JLabel("Ready");
    private final RegistrationService service = new RegistrationService();
    private int page = 0;
    private boolean loading = false;

    public EventRegistrationApp() {
        super("Campus Event Registration");
        setLayout(new BorderLayout(8, 8));

        JMenuBar menuBar = new JMenuBar();
        JMenu file = new JMenu("File");
        JMenuItem refresh = new JMenuItem("Refresh");
        JMenuItem exit = new JMenuItem("Exit");
        refresh.addActionListener(e -> loadPage(0));
        exit.addActionListener(e -> dispose());
        file.add(refresh);
        file.add(exit);
        menuBar.add(file);
        setJMenuBar(menuBar);

        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT));
        form.setBorder(BorderFactory.createTitledBorder("Student Registration"));
        form.add(new JLabel("Student ID:")); form.add(studentId);
        form.add(new JLabel("Name:")); form.add(studentName);
        form.add(event);
        JButton register = new JButton("Register");
        form.add(register);

        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.add(new JLabel("Filter event:"));
        filterPanel.add(filter);
        JButton applyFilter = new JButton("Apply Filter");
        JButton previous = new JButton("Previous");
        JButton next = new JButton("Next");
        JButton export = new JButton("Export CSV");
        filterPanel.add(applyFilter);
        filterPanel.add(previous);
        filterPanel.add(next);
        filterPanel.add(export);

        JPanel north = new JPanel(new BorderLayout());
        north.add(form, BorderLayout.NORTH);
        north.add(filterPanel, BorderLayout.SOUTH);
        add(north, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(status, BorderLayout.SOUTH);

        register.addActionListener(e -> registerStudent());
        applyFilter.addActionListener(e -> loadPage(0));
        filter.addActionListener(e -> { if (!loading) loadPage(0); });
        previous.addActionListener(e -> { if (page > 0) loadPage(page - 1); });
        next.addActionListener(e -> loadPage(page + 1));
        export.addActionListener(e -> exportCsv());

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                if (JOptionPane.showConfirmDialog(EventRegistrationApp.this,
                        "Close the application?", "Confirm",
                        JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) dispose();
            }
        });
        setSize(900, 560);
        setLocationRelativeTo(null);
        loadPage(0);
    }

    private void registerStudent() {
        try {
            service.register(studentId.getText(), studentName.getText(),
                    (String) event.getSelectedItem());
            status.setText("Registration successful.");
            loadPage(0);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Registration Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadPage(int requestedPage) {
        if (loading) return;
        loading = true;
        status.setText("Loading registrations...");
        String selected = (String) filter.getSelectedItem();
        new SwingWorker<List<Registration>, Void>() {
            @Override protected List<Registration> doInBackground() throws Exception {
                return service.getPage(selected, PAGE_SIZE, requestedPage * PAGE_SIZE);
            }
            @Override protected void done() {
                try {
                    List<Registration> rows = get();
                    model.setRowCount(0);
                    for (Registration r : rows) {
                        model.addRow(new Object[]{r.getId(), r.getStudentId(),
                                r.getStudentName(), r.getEventName()});
                    }
                    page = requestedPage;
                    status.setText("Page " + (page + 1) + " – " + rows.size() + " row(s)");
                } catch (Exception ex) {
                    status.setText("Could not load data.");
                    JOptionPane.showMessageDialog(EventRegistrationApp.this,
                            ex.getCause() == null ? ex.getMessage() : ex.getCause().getMessage(),
                            "Database Error", JOptionPane.ERROR_MESSAGE);
                } finally {
                    loading = false;
                }
            }
        }.execute();
    }

    private void exportCsv() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new java.io.File("registrations-page.csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try (java.io.PrintWriter out = new java.io.PrintWriter(chooser.getSelectedFile())) {
            out.println("ID,Student ID,Student Name,Event");
            for (int i = 0; i < model.getRowCount(); i++) {
                out.printf("%s,%s,%s,%s%n",
                        csv(model.getValueAt(i, 0)), csv(model.getValueAt(i, 1)),
                        csv(model.getValueAt(i, 2)), csv(model.getValueAt(i, 3)));
            }
            status.setText("Current page exported.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Export Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String csv(Object value) {
        String s = String.valueOf(value).replace("\"", "\"\"");
        return "\"" + s + "\"";
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EventRegistrationApp().setVisible(true));
    }
}
