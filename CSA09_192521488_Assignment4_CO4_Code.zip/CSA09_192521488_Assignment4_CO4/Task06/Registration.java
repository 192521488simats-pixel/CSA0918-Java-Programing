package Task06;

public class Registration {
    private final int id;
    private final String studentId;
    private final String studentName;
    private final String eventName;

    public Registration(int id, String studentId, String studentName, String eventName) {
        this.id = id;
        this.studentId = studentId;
        this.studentName = studentName;
        this.eventName = eventName;
    }

    public int getId() { return id; }
    public String getStudentId() { return studentId; }
    public String getStudentName() { return studentName; }
    public String getEventName() { return eventName; }
}
