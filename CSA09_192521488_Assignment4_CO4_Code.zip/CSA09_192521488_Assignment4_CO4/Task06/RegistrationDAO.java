package Task06;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RegistrationDAO {
    public void insert(String studentId, String studentName, String eventName) throws SQLException {
        String sql = "INSERT INTO registrations(student_id, student_name, event_name) VALUES (?, ?, ?)";
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, studentId);
            ps.setString(2, studentName);
            ps.setString(3, eventName);
            ps.executeUpdate();
        }
    }

    public List<Registration> findPage(String eventFilter, int limit, int offset) throws SQLException {
        String sql = "SELECT id, student_id, student_name, event_name FROM registrations "
                   + "WHERE (? = 'All' OR event_name = ?) ORDER BY id DESC LIMIT ? OFFSET ?";
        List<Registration> rows = new ArrayList<>();
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, eventFilter);
            ps.setString(2, eventFilter);
            ps.setInt(3, limit);
            ps.setInt(4, offset);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(new Registration(rs.getInt("id"), rs.getString("student_id"),
                            rs.getString("student_name"), rs.getString("event_name")));
                }
            }
        }
        return rows;
    }
}
