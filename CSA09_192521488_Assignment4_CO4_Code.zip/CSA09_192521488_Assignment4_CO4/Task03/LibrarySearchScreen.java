package Task03;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class LibrarySearchScreen extends JFrame {
    private final JTextField searchField = new JTextField(22);
    private final JComboBox<String> category =
            new JComboBox<>(new String[]{"All", "Title", "Author", "Subject"});
    private final DefaultTableModel model =
            new DefaultTableModel(new Object[]{"Book ID", "Title", "Author", "Category"}, 0);
    private final JTable results = new JTable(model);
    private final JLabel status = new JLabel("Ready");

    public LibrarySearchScreen() {
        super("Campus Library Search");
        setLayout(new BorderLayout(8, 8));

        JLabel title = new JLabel("Campus Library Search", SwingConstants.CENTER);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 20f));
        add(title, BorderLayout.NORTH);

        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchRow.add(new JLabel("Search:"));
        searchRow.add(searchField);
        searchRow.add(category);
        JButton search = new JButton("Search");
        searchRow.add(search);

        JPanel top = new JPanel(new BorderLayout());
        top.add(title, BorderLayout.NORTH);
        top.add(searchRow, BorderLayout.SOUTH);
        add(top, BorderLayout.NORTH);

        results.setFillsViewportHeight(true);
        add(new JScrollPane(results), BorderLayout.CENTER);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton prev = new JButton("Prev");
        JButton next = new JButton("Next");
        JButton reserve = new JButton("Reserve");
        bottom.add(prev);
        bottom.add(next);
        bottom.add(reserve);

        JPanel south = new JPanel(new BorderLayout());
        south.add(bottom, BorderLayout.NORTH);
        south.add(status, BorderLayout.SOUTH);
        add(south, BorderLayout.SOUTH);

        search.addActionListener(e -> searchBooks());
        searchField.addActionListener(e -> searchBooks());
        prev.addActionListener(e -> status.setText("Previous page requested."));
        next.addActionListener(e -> status.setText("Next page requested."));
        reserve.addActionListener(e -> {
            int row = results.getSelectedRow();
            if (row < 0) status.setText("Select a book to reserve.");
            else status.setText("Reservation request: " + model.getValueAt(row, 1));
        });

        loadSampleData();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(620, 380));
        setSize(760, 500);
        setLocationRelativeTo(null);
    }

    private void loadSampleData() {
        model.addRow(new Object[]{"B101", "Java Programming", "Herbert Schildt", "Programming"});
        model.addRow(new Object[]{"B102", "Database Systems", "R. Elmasri", "Computer Science"});
        model.addRow(new Object[]{"B103", "Operating Systems", "A. Silberschatz", "Computer Science"});
    }

    private void searchBooks() {
        String query = searchField.getText().trim().toLowerCase();
        String selectedCategory = (String) category.getSelectedItem();
        for (int i = model.getRowCount() - 1; i >= 0; i--) {
            String title = model.getValueAt(i, 1).toString().toLowerCase();
            String author = model.getValueAt(i, 2).toString().toLowerCase();
            String cat = model.getValueAt(i, 3).toString().toLowerCase();
            boolean matchesText = query.isEmpty() || title.contains(query)
                    || author.contains(query) || cat.contains(query);
            boolean matchesCategory = "All".equals(selectedCategory)
                    || ("Title".equals(selectedCategory) && title.contains(query))
                    || ("Author".equals(selectedCategory) && author.contains(query))
                    || ("Subject".equals(selectedCategory) && cat.contains(query));
            if (!(matchesText && matchesCategory)) model.removeRow(i);
        }
        status.setText(model.getRowCount() + " result(s). (Sample data)");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LibrarySearchScreen().setVisible(true));
    }
}
