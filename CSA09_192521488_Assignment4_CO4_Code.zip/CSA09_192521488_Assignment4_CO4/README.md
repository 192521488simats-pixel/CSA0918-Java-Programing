# CSA09 – Assignment 4 (CO4): Event-Driven GUI Design

**Student:** S. Hariharan  
**Register Number:** 192521488  
**Course:** Programming in Java (CSA09)

## Contents
- `Task01/` – Fee window and separate service layer (Task 1.2)
- `Task02/` – Event table, component hierarchy, pseudocode and event trace
- `Task03/` – Campus library search screen using nested Swing layouts
- `Task04/` – Repaint-safe AWT drawing pad; completed TODOs
- `Task05/` – Four event-handling styles and completed lambda converter
- `Task06/` – Layered Swing + JDBC event-registration application and SQL script
- `ANSWERS.md` – Written answers, design defence and complexity comparisons

## Requirements
- JDK 8 or later (JDK 17 recommended)
- MySQL Server 8.x for Task 1 database payment and Task 6
- MySQL Connector/J JAR for Task 1 and Task 6 database execution

## Compile and run
Open a terminal in this folder. Compile each task separately:

```bash
javac -d Task01/out Task01/*.java
java -cp Task01/out Task01.FeeWindow
```

```bash
javac -d Task03/out Task03/*.java
java -cp Task03/out Task03.LibrarySearchScreen
```

```bash
javac -d Task04/out Task04/*.java
java -cp Task04/out Task04.DrawPad
```

```bash
javac -d Task05/out Task05/*.java
java -cp Task05/out Task05.ConverterLambda
```

Task 5 alternatives:
```bash
java -cp Task05/out Task05.ConverterFrameListener
java -cp Task05/out Task05.ConverterNamedInner
java -cp Task05/out Task05.ConverterAnonymous
```

Task 6: first execute `Task06/schema.sql` in MySQL. Update database URL/user/password in `Task06/DB.java`. Add MySQL Connector/J to the classpath:
```bash
javac -cp ".;mysql-connector-j-8.x.x.jar" -d Task06/out Task06/*.java
java -cp "Task06/out;mysql-connector-j-8.x.x.jar" Task06.EventRegistrationApp
```
On Linux/macOS replace `;` in the classpath with `:`.

## Execution notes
- Task 1 uses JDBC prepared statements; update connection details in `FeeService.java`.
- Task 3 is a local demonstration with sample book results; the screen and layout are fully functional.
- Task 4 stores click points and redraws them from `paint()`, so they survive repainting.
- Task 5 demonstrates four listener styles. The lambda version uses one shared listener for the button and Enter key.
- Task 6 uses `SwingWorker` and paginated SQL (`LIMIT`/`OFFSET`) so database work does not block Swing's event-dispatch thread.
- Screenshots must be captured after running the programs on your own computer. They cannot be truthfully supplied by a source-code ZIP alone.

## GitHub submission reminder
Create a repository named `CSA09-192521488-Assignment4`, add these folders, commit each task progressively, upload your screenshots and README, and put the working repository link on the report cover page.
