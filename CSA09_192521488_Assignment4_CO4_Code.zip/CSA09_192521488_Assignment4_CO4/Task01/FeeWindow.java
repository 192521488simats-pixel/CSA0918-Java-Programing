package Task01;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class FeeWindow extends JFrame {
    private final JTextField regNo = new JTextField(16);
    private final JTextField amount = new JTextField(16);
    private final JLabel status = new JLabel("Enter payment details.");
    private final FeeService service = new FeeService();

    public FeeWindow() {
        super("Student Fee Payment");
        setLayout(new BorderLayout(8, 8));

        JPanel form = new JPanel(new GridLayout(2, 2, 8, 8));
        form.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        form.add(new JLabel("Registration number:"));
        form.add(regNo);
        form.add(new JLabel("Amount (Rs.):"));
        form.add(amount);

        JButton pay = new JButton("Pay");
        JButton clear = new JButton("Clear");
        JButton receipt = new JButton("Receipt");
        JPanel actions = new JPanel(new FlowLayout());
        actions.add(pay);
        actions.add(clear);
        actions.add(receipt);

        add(form, BorderLayout.CENTER);
        add(actions, BorderLayout.SOUTH);
        add(status, BorderLayout.NORTH);

        pay.addActionListener(e -> processPayment());
        clear.addActionListener(e -> {
            regNo.setText("");
            amount.setText("");
            status.setText("Fields cleared.");
        });
        receipt.addActionListener(e ->
            JOptionPane.showMessageDialog(this, status.getText(),
                    "Payment Receipt", JOptionPane.INFORMATION_MESSAGE));

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { dispose(); }
        });
        setSize(420, 220);
        setLocationRelativeTo(null);
    }

    private void processPayment() {
        try {
            status.setText(service.payFee(regNo.getText(), amount.getText()));
        } catch (Exception ex) {
            status.setText("Payment failed.");
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Payment Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FeeWindow().setVisible(true));
    }
}
