# Task 2 – Hospital Outpatient Appointment Desk

## 2.1 Event model

| Event source | Event object | Listener | Action |
|---|---|---|---|
| Department JComboBox | ItemEvent | ItemListener | Load matching doctors and reset doctor selection |
| Doctor JComboBox | ItemEvent | ItemListener | Update selected doctor |
| Time-slot JComboBox | ItemEvent | ItemListener | Update selected slot |
| Book JButton | ActionEvent | ActionListener | Validate fields and book appointment |
| Patient ID JTextField | ActionEvent | ActionListener | Optional validation when Enter is pressed |
| Window close control | WindowEvent | WindowListener / WindowAdapter | Ask before closing if booking is in progress |

## 2.2 Component containment hierarchy

```text
JFrame AppointmentFrame (BorderLayout)
├── JPanel form (GridBagLayout)
│   ├── JLabel + JTextField patientId
│   ├── JLabel + JComboBox department
│   ├── JLabel + JComboBox doctor
│   └── JLabel + JComboBox timeSlot
├── JPanel actions (FlowLayout)
│   └── JButton book
└── JLabel status (BorderLayout.SOUTH)
```

## 2.3 Handler pseudocode

### (a) Refresh doctor list
```text
PROCEDURE refreshDoctors
    selectedDepartment ← departmentCombo.getSelectedItem()
    doctorCombo.removeAllItems()
    doctorList ← doctorsByDepartment.get(selectedDepartment)
    FOR EACH doctor IN doctorList
        doctorCombo.addItem(doctor)
    END FOR
    IF doctorList is empty THEN
        statusLabel.setText("No doctors available")
    END IF
END PROCEDURE
```

### (b) Validate and book
```text
PROCEDURE bookAppointment
    patient ← patientIdField.getText().trim()
    department ← departmentCombo.getSelectedItem()
    doctor ← doctorCombo.getSelectedItem()
    slot ← timeSlotCombo.getSelectedItem()

    IF patient is empty OR department is null OR doctor is null OR slot is null THEN
        display "Complete all appointment details"
        RETURN
    END IF

    IF patient does not exist THEN
        display "Invalid patient ID"
        RETURN
    END IF

    bookingResult ← appointmentService.book(patient, department, doctor, slot)
    IF bookingResult is successful THEN
        display confirmation number
    ELSE
        display booking error
    END IF
END PROCEDURE
```

## 2.4 Event trace and applet comparison

1. `main()` schedules frame creation with `SwingUtilities.invokeLater`.
2. Frame constructor creates components and registers listeners.
3. `setVisible(true)` displays the frame.
4. User input produces `ItemEvent` or `ActionEvent`.
5. Swing dispatches the event to the registered listener.
6. Handler refreshes choices or calls the booking service.
7. On close, `windowClosing(WindowEvent)` runs; it asks for confirmation if a booking is in progress.
8. If confirmed, `dispose()` releases the window resources.

An applet uses the lifecycle methods `init()`, `start()`, `paint()`, `stop()` and `destroy()`. A normal desktop frame does not use this applet lifecycle; it responds to constructor setup, visibility, events and window-closing methods.

## Alternative concept and complexity

**Preloaded Map:** Load all department-to-doctor lists once into `Map<String, List<Doctor>>`. A department change performs a map lookup, typically O(1), then fills the combo box in O(m) for m doctors in that department. Memory is O(d × m) in the stated equal-list model, or O(total doctors + d) generally.

**Database query on every change:** Each change incurs database/network latency plus O(m) transfer and display work. It uses less persistent client memory (roughly O(m) for the current department), but repeated changes create repeated queries and make the UI more dependent on network/database availability.
